# create bucket
awslocal s3 mb s3://sample-bucket
awslocal s3 ls

